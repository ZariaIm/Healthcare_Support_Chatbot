This is code for our healthcare support chatbot for course project ECE4179.

Contributing authors:
Zaria Imran
Fatemeh (Ava) Khosravi
Lachlan Muirden

Version date released: 22 Oct 2021

Link for downloading the trained chatbot model:
https://drive.google.com/file/d/1ALMpVo_N4PpxrfsPmoPv6Dr-Uy6HmsGq/view?usp=sharing